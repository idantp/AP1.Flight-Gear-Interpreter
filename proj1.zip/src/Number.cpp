//
// Created by roy on 17/12/18.
//

#include "Number.h"

//calculate the expresiion.
double Number::calculate() {
    return this->num;
}

//constructor.
Number::Number(double num) {
    this->num = num;
}